public class Lomuto 
{
	public static int partition(int[] A, int low, int high)
	{
		int a;
		int b;
		int s = low;
		int p = A[low];
		
		// for loop to scan from low to high in array
		for ( int i = low + 1; i <= high; i++)
		{
			// checks if number is less than pivot
			if ( A[i] < p)
			{
				s++;
				// swap A[s] and A[i]
				a = A[i];
				b = A[s];
				A[s] = a;
				A[i] = b;
			}
		}
		// swap A[l] and A[s]
		a = A[low];
		b = A[s];
		A[s] = a;
		A[low] = b;
		
		System.out.println("Lomuto Completed");
		return s;
	}
}
